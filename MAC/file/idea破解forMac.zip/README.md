### 1. 步骤:

1. 在/Applications/IntelliJ IDEA点击右键,显示包内容;
2. 将idea.vmoptions和JetbrainsIdesCrack-4.2-release.jar两个文件放到/Contents/bin下;
3. 打开idea,在Help/register/ActivationCode输入以下码:

```json
ThisCrackLicenseId-{
"licenseId":"ThisCrackLicenseId",
"licenseeName":"Rover12421",
"assigneeName":"",
"assigneeEmail":"rover12421@163.com",
"licenseRestriction":"For Rover12421 Crack, Only Test! Please support genuine!!!",
"checkConcurrentUse":false,
"products":[
{"code":"II","paidUpTo":"9998-12-31"},
{"code":"DM","paidUpTo":"9998-12-31"},
{"code":"AC","paidUpTo":"9998-12-31"},
{"code":"RS0","paidUpTo":"9998-12-31"},
{"code":"WS","paidUpTo":"9998-12-31"},
{"code":"DPN","paidUpTo":"9998-12-31"},
{"code":"RC","paidUpTo":"9998-12-31"},
{"code":"PS","paidUpTo":"9998-12-31"},
{"code":"DC","paidUpTo":"9998-12-31"},
{"code":"RM","paidUpTo":"9998-12-31"},
{"code":"CL","paidUpTo":"9998-12-31"},
{"code":"PC","paidUpTo":"9998-12-31"}
],
"hash":"2911276/0",
"gracePeriodDays":7,
"autoProlongated":false}
```

### 2. 说明:
本方法实测用于Mac下的2018.3版IDEA可破解至9999年;
